clear

javac comp26120/greedy_kp.java comp26120/KnapSack.java
javac comp26120/dp_kp.java comp26120/KnapSack.java

# echo "expected..."
# java comp26120.dp_kp ../data/tst_one.txt
# echo "......"
# java comp26120.greedy_kp ../data/tst_one.txt
# echo "-------------------------------------------------"

# echo "expected..."
# java comp26120.dp_kp ../data/tst_two.txt
# echo "......"
# java comp26120.greedy_kp ../data/tst_two.txt
# echo "-------------------------------------------------"

# echo "expected..."
# java comp26120.dp_kp ../data/tst_three.txt
# echo "......"
# java comp26120.greedy_kp ../data/tst_three.txt
# echo "-------------------------------------------------"

# echo "expected..."
# java comp26120.dp_kp ../data/tst_four.txt
# echo "......"
# java comp26120.greedy_kp ../data/tst_four.txt
# echo "-------------------------------------------------"

# echo "expected..."
# java comp26120.dp_kp ../data/tst_five.txt
# echo "......"
# java comp26120.greedy_kp ../data/tst_five.txt
# echo "-------------------------------------------------"

echo "expected..."
java comp26120.dp_kp ../data/hard.2000.txt
echo "......"
java comp26120.greedy_kp ../data/hard.2000.txt
echo "-------------------------------------------------"